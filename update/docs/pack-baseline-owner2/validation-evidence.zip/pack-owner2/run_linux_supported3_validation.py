"""Run unchanged default pytest selection in isolated Linux clones; no exclusions."""
from __future__ import annotations
import concurrent.futures
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/home/youngjo/.cache/byul-pack-owner2-validation-20261101-supported3')
OUT = ROOT.parent / 'byul-pack-owner2-supported3-final-validation-20261101'
OUT.mkdir(exist_ok=True)
ENV = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8',
           GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.autocrlf', GIT_CONFIG_VALUE_0='false')

def run(command, cwd, name):
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    tick = time.monotonic()
    with (OUT / (name + '.log')).open('w', encoding='utf-8') as stream:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    record = dict(command=command, cwd=str(cwd), started_at=started,
                  finished_at=dt.datetime.now(dt.timezone.utc).isoformat(),
                  parent_wall_seconds=time.monotonic()-tick, exit_code=result.returncode)
    (OUT / (name + '-timing.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(name=name, **record)), flush=True)
    return record

def revision(root):
    return subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip()

expected_head = revision(ROOT)
run(['uv','sync','--python','/usr/bin/python3.12','--locked'], ROOT/'update', 'sync')
collection = run(['uv','run','pytest','--collect-only','-q','--basetemp='+str(OUT/'collect-temp')],
                 ROOT/'update', 'collection')
if collection['exit_code']:
    raise SystemExit(collection['exit_code'])
nodes = [line for line in (OUT/'collection.log').read_text().splitlines()
         if line.startswith('tests/') and '::' in line]
files = {}
for node in nodes:
    name=node.split('::',1)[0]
    files[name]=files.get(name,0)+1
groups=[[] for _ in range(4)]
counts=[0]*4
for name,count in sorted(files.items(),key=lambda pair:(-pair[1],pair[0])):
    idx=counts.index(min(counts))
    groups[idx].append(name)
    counts[idx]+=count
assert len({name for group in groups for name in group}) == len(files)
assert sum(map(len,groups)) == len(files)
manifest=dict(source_head=expected_head, selected_nodes=len(nodes), files=len(files),
              files_by_shard=groups, selected_by_shard=counts,
              unchanged_default_addopts=True, additional_exclusions=[],
              environment={key:ENV[key] for key in ('PYTHONUTF8','PYTHONIOENCODING',
                'GIT_CONFIG_COUNT','GIT_CONFIG_KEY_0','GIT_CONFIG_VALUE_0')})
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

def shard(index):
    root=ROOT.parent/(ROOT.name+'-shard-'+str(index))
    result=run(['git','clone','--shared','--branch','codex/pack-baseline-owner2-20261101',str(ROOT),str(root)],
               ROOT.parent,'clone-'+str(index))
    if result['exit_code']:return result
    assert revision(root)==expected_head
    synced=run(['uv','sync','--python','/usr/bin/python3.12','--locked'],root/'update','sync-'+str(index))
    if synced['exit_code']:return synced
    result=run(['uv','run','pytest','-q',*groups[index],
                '--basetemp='+str(OUT/('temp-'+str(index)))],root/'update','pytest-'+str(index))
    status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=no'],cwd=root,text=True)
    result['tracked_status_after']=status
    result['source_head_after']=revision(root)
    assert not status, status
    assert result['source_head_after']==expected_head
    return result

tick=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(shard,range(4)))
summary=dict(manifest=manifest,results=results,parent_total_wall_seconds=time.monotonic()-tick,
             scope='same default suite split by file in four isolated clones; not engine/Kubernetes/GPU measurement')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
raise SystemExit(int(any(row['exit_code'] for row in results)))
